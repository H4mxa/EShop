import React from "react";
import CollectionItem from "components/collection-item/CollectionItem";

import "./Collection.scss";

const Collection = ({ match }) => {
  console.log(match);
  return (
    <div className="collection-page">
      <h2>CATEGORY pAGE</h2>
    </div>
  );
};

export default Collection;
